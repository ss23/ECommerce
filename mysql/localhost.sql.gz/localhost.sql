-- phpMyAdmin SQL Dump
-- version 3.2.3
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jan 20, 2010 at 02:50 PM
-- Server version: 5.0.84
-- PHP Version: 5.2.12-pl0-gentoo

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `ecommerce`
--
CREATE DATABASE `ecommerce` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `ecommerce`;

-- --------------------------------------------------------

--
-- Table structure for table `actions`
--

CREATE TABLE IF NOT EXISTS `actions` (
  `uuid` char(36) NOT NULL,
  `name` varchar(60) NOT NULL,
  `description` longtext NOT NULL,
  PRIMARY KEY  (`uuid`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `actions`
--


-- --------------------------------------------------------

--
-- Table structure for table `carts`
--

CREATE TABLE IF NOT EXISTS `carts` (
  `session_uuid` char(36) NOT NULL,
  `plan_uuid` char(36) NOT NULL,
  `location_uuid` char(36) NOT NULL,
  `coupon_uuid` char(36) NOT NULL,
  PRIMARY KEY  (`session_uuid`),
  KEY `plan_uuid` (`plan_uuid`,`location_uuid`,`coupon_uuid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `carts`
--


-- --------------------------------------------------------

--
-- Table structure for table `countries`
--

CREATE TABLE IF NOT EXISTS `countries` (
  `code` char(2) NOT NULL,
  `name` varchar(250) NOT NULL,
  PRIMARY KEY  (`code`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `countries`
--


-- --------------------------------------------------------

--
-- Table structure for table `coupons`
--

CREATE TABLE IF NOT EXISTS `coupons` (
  `uuid` char(36) NOT NULL,
  `offer_uuid` char(36) NOT NULL,
  `redeemed` tinyint(1) NOT NULL,
  `user_uuid` char(36) NOT NULL COMMENT 'redeemer uuid',
  PRIMARY KEY  (`uuid`),
  KEY `offer_uuid` (`offer_uuid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `coupons`
--


-- --------------------------------------------------------

--
-- Table structure for table `disabled_reasons`
--

CREATE TABLE IF NOT EXISTS `disabled_reasons` (
  `uuid` char(36) NOT NULL,
  `name` varchar(20) NOT NULL,
  `description` mediumtext NOT NULL,
  PRIMARY KEY  (`uuid`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `disabled_reasons`
--


-- --------------------------------------------------------

--
-- Table structure for table `disabled_users`
--

CREATE TABLE IF NOT EXISTS `disabled_users` (
  `uuid` char(36) NOT NULL,
  `user_uuid` char(36) NOT NULL,
  `disabled_by_user_uuid` char(36) NOT NULL,
  `disabled_uuid` char(36) NOT NULL,
  `comment` mediumtext NOT NULL,
  PRIMARY KEY  (`uuid`),
  KEY `user_uuid` (`user_uuid`,`disabled_by_user_uuid`,`disabled_uuid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `disabled_users`
--


-- --------------------------------------------------------

--
-- Table structure for table `images`
--

CREATE TABLE IF NOT EXISTS `images` (
  `uuid` char(36) NOT NULL,
  `path` varchar(250) NOT NULL,
  `caption` varchar(250) NOT NULL,
  `timestamp` timestamp NOT NULL default CURRENT_TIMESTAMP,
  PRIMARY KEY  (`uuid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `images`
--


-- --------------------------------------------------------

--
-- Table structure for table `images_plans`
--

CREATE TABLE IF NOT EXISTS `images_plans` (
  `plan_uuid` char(36) NOT NULL,
  `image_uuid` char(36) NOT NULL,
  KEY `plan_uuid` (`plan_uuid`),
  KEY `image_uuid` (`image_uuid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `images_plans`
--


-- --------------------------------------------------------

--
-- Table structure for table `images_revisions`
--

CREATE TABLE IF NOT EXISTS `images_revisions` (
  `uuid` char(36) NOT NULL,
  `revision_uuid` char(36) NOT NULL,
  `image_uuid` char(36) NOT NULL,
  `position` int(11) NOT NULL,
  PRIMARY KEY  (`uuid`),
  KEY `revision_uuid` (`revision_uuid`,`image_uuid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `images_revisions`
--


-- --------------------------------------------------------

--
-- Table structure for table `ips`
--

CREATE TABLE IF NOT EXISTS `ips` (
  `uuid` char(36) NOT NULL,
  `ip` int(10) unsigned NOT NULL,
  `user_uuid` int(11) NOT NULL,
  `timestamp` timestamp NOT NULL default '0000-00-00 00:00:00' on update CURRENT_TIMESTAMP,
  PRIMARY KEY  (`uuid`),
  KEY `ip` (`ip`,`user_uuid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ips`
--


-- --------------------------------------------------------

--
-- Table structure for table `locations`
--

CREATE TABLE IF NOT EXISTS `locations` (
  `uuid` char(36) NOT NULL,
  `country` varchar(60) NOT NULL,
  `state_province` varchar(60) NOT NULL,
  PRIMARY KEY  (`uuid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `locations`
--


-- --------------------------------------------------------

--
-- Table structure for table `locations_plans`
--

CREATE TABLE IF NOT EXISTS `locations_plans` (
  `uuid` char(36) NOT NULL,
  `price` decimal(10,2) unsigned NOT NULL,
  `location_uuid` char(36) NOT NULL,
  `plan_uuid` char(36) NOT NULL,
  PRIMARY KEY  (`uuid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `locations_plans`
--


-- --------------------------------------------------------

--
-- Table structure for table `logs`
--

CREATE TABLE IF NOT EXISTS `logs` (
  `uuid` char(36) NOT NULL,
  `ip_uuid` char(36) NOT NULL,
  `user_uuid` char(36) NOT NULL,
  `affected_user_uuid` char(36) NOT NULL,
  `action_uuid` char(36) NOT NULL,
  `comment` longtext NOT NULL,
  PRIMARY KEY  (`uuid`),
  KEY `ip_uuid` (`ip_uuid`,`user_uuid`,`action_uuid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `logs`
--


-- --------------------------------------------------------

--
-- Table structure for table `offers`
--

CREATE TABLE IF NOT EXISTS `offers` (
  `uuid` char(36) NOT NULL,
  `description` text NOT NULL,
  `start_timestamp` timestamp NOT NULL default CURRENT_TIMESTAMP,
  `expire_timestamp` timestamp NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (`uuid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `offers`
--


-- --------------------------------------------------------

--
-- Table structure for table `offers_plans`
--

CREATE TABLE IF NOT EXISTS `offers_plans` (
  `offer_uuid` char(36) NOT NULL,
  `plan_uuid` char(36) NOT NULL,
  KEY `plan_uuid` (`plan_uuid`),
  KEY `offer_uuid` (`offer_uuid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `offers_plans`
--


-- --------------------------------------------------------

--
-- Table structure for table `pages`
--

CREATE TABLE IF NOT EXISTS `pages` (
  `uuid` char(36) NOT NULL,
  `name` varchar(250) NOT NULL,
  `revision_uuid` char(36) NOT NULL,
  PRIMARY KEY  (`uuid`),
  UNIQUE KEY `name` (`name`),
  KEY `revision` (`revision_uuid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `pages`
--


-- --------------------------------------------------------

--
-- Table structure for table `plans`
--

CREATE TABLE IF NOT EXISTS `plans` (
  `uuid` char(36) NOT NULL,
  `name` varchar(30) NOT NULL,
  `slots` int(11) NOT NULL,
  `image` varchar(50) NOT NULL,
  PRIMARY KEY  (`uuid`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `plans`
--

INSERT INTO `plans` (`uuid`, `name`, `slots`, `image`) VALUES
('80ae9b93-f47a-11de-b737-00016cacc248', 'Plan 1', 10, 'plan1.png'),
('582c949e-0425-11df-b23b-00016cacc248', 'plan 2', 15, 'rawr.png');

-- --------------------------------------------------------

--
-- Table structure for table `revisions`
--

CREATE TABLE IF NOT EXISTS `revisions` (
  `uuid` char(36) NOT NULL,
  `content` longtext NOT NULL,
  `timestamp` timestamp NOT NULL default CURRENT_TIMESTAMP,
  `user_uuid` char(36) NOT NULL,
  PRIMARY KEY  (`uuid`),
  KEY `user_uuid` (`user_uuid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `revisions`
--


-- --------------------------------------------------------

--
-- Table structure for table `sessions`
--

CREATE TABLE IF NOT EXISTS `sessions` (
  `uuid` int(23) unsigned NOT NULL,
  `last_active` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `ip_uuid` char(36) NOT NULL,
  PRIMARY KEY  (`uuid`),
  KEY `ip` (`ip_uuid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sessions`
--


-- --------------------------------------------------------

--
-- Table structure for table `sessions_users`
--

CREATE TABLE IF NOT EXISTS `sessions_users` (
  `uuid` char(36) NOT NULL,
  `session_uuid` int(23) NOT NULL,
  `user_uuid` char(36) NOT NULL,
  `expire` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  PRIMARY KEY  (`uuid`),
  UNIQUE KEY `session_uuid` (`session_uuid`,`user_uuid`),
  KEY `expire` (`expire`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sessions_users`
--


-- --------------------------------------------------------

--
-- Table structure for table `user_profiles`
--

CREATE TABLE IF NOT EXISTS `user_profiles` (
  `uuid` char(36) NOT NULL,
  `email` varchar(320) NOT NULL,
  `username` varchar(25) NOT NULL,
  `password` char(64) NOT NULL,
  `first_name` varchar(30) NOT NULL,
  `last_name` varchar(30) NOT NULL,
  `country_code` char(2) NOT NULL,
  `state_province` varchar(60) NOT NULL,
  `disabled` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`uuid`),
  UNIQUE KEY `email` (`email`),
  KEY `disabled` (`disabled`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_profiles`
--


-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `uuid` char(36) NOT NULL,
  `username` varchar(25) NOT NULL,
  `password` char(64) NOT NULL,
  `disabled` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`uuid`),
  UNIQUE KEY `username` (`username`),
  KEY `disabled` (`disabled`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

